/********************************************************************************
 * Description  :
 * Version      : 1.0
 * Author       : YingKang Zhong
 * Date         : 2022-05-02 15:12:02
 * LastEditors  : YingKang Zhong
 * LastEditTime : 2022-05-03 10:57:23
 * FilePath     : \\PB19111713_钟颖康_exp1\\CSP\\src\\CSP_PB19111713.c
 * Copyright (C) 2022 YingKang Zhong. All rights reserved.
 ********************************************************************************/
#pragma warning(disable : 4996)
#include <stdio.h>
#include <string.h>

#define MAX_WORKERS 50
#define DEBUG 0
#define PROCESS 0
#define DOMAIN_TEST 0
#define PorF_TEST 0

int DAY[8][MAX_WORKERS];               // DAY[day][worker]: 0->rest; 1->work; 10->to be searched
int SENIOR[MAX_WORKERS];               // SENIOR[worker]: 0->junior; 1->senior
int AGAINST[MAX_WORKERS][MAX_WORKERS]; // AGAINST[workerA][workerB]: 1->workerA against with workerB
int domain[8][MAX_WORKERS][5];
/*************************************************************************************
 * domain[day][worker][0]: 0->worker can't rest on day; 1->worker can rest on day
 * domain[day][worker][1]: 0->worker can't work on day; 1->worker can work on day
 * domain[day][worker][2]: domain[day][worker][0] + domain[day][worker][1]
 * ***********************************************************************************/

int num_workers = 0;  // the number of workers
int least_worker = 0; // the least number of employees go to work every day
int num_against = 0;  // the number of against pairs

void Init();
void SetCell(int da, int wo, int sta);
int Solve();
int SelectCell();
int SENIOR_LAST(int da);
long long WORKER_LAST(int da);
int WORK_DAY(int wo);
void OutPut();

int main()
{
    Init();
    int test = Solve();
    if (test == 1)
    {
#if PorF_TEST
        printf("\nsolve succ\n");
#endif
        OutPut();
    }
#if PorF_TEST
    else
        printf("\nsolve fail\n");
#endif
}

void Init()
/*********************************************************************************
 * Input:
 * the number of workers,
 * for each worker if he is a senior or not,
 * the number of least worker on duty a day,
 * the number of pairs against pairs,
 * the detailed against pairs.
 * *******************************************************************************/
{
    int i, j;
    scanf("%d", &num_workers);
    for (i = 1; i <= 7; i++)
        for (j = 1; j <= num_workers; j++)
        {
            DAY[i][j] = 10; // 10 means to be searched
            domain[i][j][0] = 1;
            domain[i][j][1] = 1;
            domain[i][j][2] = 2;
        }
    for (i = 1; i <= num_workers; i++)
        scanf("%d", &SENIOR[i]);
    scanf("%d", &least_worker);
    scanf("%d", &num_against);
    int tmpa, tmpb;
    for (i = 1; i <= num_against; i++)
    {
        scanf("%d%d", &tmpa, &tmpb);
        AGAINST[tmpa][tmpb] = 1;
        AGAINST[tmpb][tmpa] = 1;
    }
}

void SetCell(int da, int wo, int sta)
{
    long long tmp;
    DAY[da][wo] = sta;
    tmp = WORKER_LAST(da);
    if (tmp != 0)
    /******************************************************************************
     * Whether employee wo works today or not,
     * if the number of remaining non searched employees
     * plus the number of employees at work is exactly equal to least_worker
     * ****************************************************************************/
    {
        int last_few = ((int)(tmp % MAX_WORKERS));
        while (last_few != 0)
        {
            domain[da][last_few][2] -= domain[da][last_few][0];
            domain[da][last_few][0] = 0; // These unsearched employees can't rest today
            tmp = (tmp - last_few) / MAX_WORKERS;
            last_few = tmp % MAX_WORKERS;
        }
    }
    if (sta == 0)
    // if employee wo rest on day
    {
        if (da >= 2 && da <= 6 && DAY[da - 1][wo] == 0)
        // If worker wo has taken two consecutive rest this week(yesterday & today)
        {
            domain[da + 1][wo][2] -= domain[da + 1][wo][0];
            domain[da + 1][wo][0] = 0; // can't rest tomorrow this week
        }
        if (da >= 3 && da <= 7 && DAY[da - 1][wo] == 0)
        // If worker wo has taken two consecutive rest this week(yesterday & today)
        {
            domain[da - 2][wo][2] -= domain[da - 2][wo][0];
            domain[da - 2][wo][0] = 0; // can't rest the day before yesterday this week
        }
        if (da >= 1 && da <= 5 && DAY[da + 1][wo] == 0)
        // If worker wo has taken two consecutive rest this week(today & tomorrow)
        {
            domain[da + 2][wo][2] -= domain[da + 2][wo][0];
            domain[da + 2][wo][0] = 0; // can't rest the day after tomorrow this week
        }
        if (da >= 2 && da <= 6 && DAY[da + 1][wo] == 0)
        // If worker wo has taken two consecutive rest this week(today & tomorrow)
        {
            domain[da - 1][wo][2] -= domain[da - 1][wo][0];
            domain[da - 1][wo][0] = 0; // can't rest yesterday this week
        }
        if (da >= 3 && da <= 7 && DAY[da - 2][wo] == 0)
        // If worker D has rested the next day this week(the day before yesterday & today)
        {
            domain[da - 1][wo][2] -= domain[da - 1][wo][0];
            domain[da - 1][wo][0] = 0; // can't rest yesterday this week
        }
        if (da >= 1 && da <= 5 && DAY[da + 2][wo] == 0)
        // If worker D has rested the next day this week(the day after tomorrow & today)
        {
            domain[da + 1][wo][2] -= domain[da + 1][wo][0];
            domain[da + 1][wo][0] = 0; // can't rest tomorrow this week
        }
        if (SENIOR[wo] == 1 && (tmp = SENIOR_LAST(da)) && (tmp != 0))
        /***************************************************************************************
         * If the senior employee wo has a rest today,
         * and the person who has been searched today has no senior
         * and there is only one senior who has not been searched
         * *************************************************************************************/
        {
            domain[da][tmp][2] -= domain[da][tmp][0];
            domain[da][tmp][0] = 0; // the last senior can't rest today
        }
    }
    if (sta == 1)
    // if employee wo work on day
    {
        for (tmp = 1; tmp <= num_workers; tmp++)
        {
            if (AGAINST[wo][tmp] == 1)
            // Someone doesn't want to work with wo all day
            {
                domain[da][tmp][2] -= domain[da][tmp][1];
                domain[da][tmp][1] = 0; // These employees can't work today
            }
        }
        if (WORK_DAY(wo) == 5)
        /******************************************************************
         * If the employee wo has been on work for 5 days this week,
         * he must rest for the remaining 2 days
         * ****************************************************************/
        {
            for (tmp = 1; tmp <= 7; tmp++)
                if (DAY[tmp][wo] == 10) // find the unsearched days
                {
                    domain[tmp][wo][2] -= domain[tmp][wo][1];
                    domain[tmp][wo][1] = 0; // can't work on these days
                }
        }
    }
}

int Solve()
// select the day&worker with the min domain
{
    int da, wo;
    wo = SelectCell() % MAX_WORKERS;
    da = (SelectCell() - wo) / MAX_WORKERS;
    if (da == -1 && wo == -1)
        return 1;
    if (domain[da][wo][2] == 0)
        return 0;
#if PROCESS
    OutPut();
    puts("");
#endif
    // Save current status
    int tmp_domain[8][MAX_WORKERS][5];
    memcpy(tmp_domain, domain, sizeof(domain));
    // Traverse the optional work/rest status of employee wo on day da
    for (int sta = 0; sta <= 1; sta++)
        if (domain[da][wo][sta] == 1)
        {
            SetCell(da, wo, sta);
            if (Solve() == 1)
                return 1;
            // Restore state
            memcpy(domain, tmp_domain, sizeof(domain));
        }
    // there's no solution
    DAY[da][wo] = 10;
    return 0;
}

int SelectCell()
{
    int da = -1, wo = -1, choice = 3;
    for (int i = 1; i <= 7; i++)
        for (int j = 1; j <= num_workers; j++)
            if (DAY[i][j] == 10 && domain[i][j][2] < choice)
            {
                da = i;
                wo = j;
                choice = domain[i][j][2];
            }
    return (da * MAX_WORKERS + wo);
}

int SENIOR_LAST(int da)
/************************************************************
 * If there is no senior on work today
 * and there is only one senior left who is not searched，
 * return the unique  unsearched senior employee number，
 * otherwise return 0
 ************************************************************/
{
    int last = 0, tmp[MAX_WORKERS];
    for (int wo = 1; wo <= num_workers; wo++)
    {
        if (SENIOR[wo] == 1)
        {
            if (DAY[da][wo] == 1)
                // If there is one senior on work today, return 0
                return 0;
            else if (DAY[da][wo] == 0)
                // If the senior rest today, continue
                continue;
            else if (DAY[da][wo] == 10 && last == 0)
                // Record the first senior who is not searched
                last = wo;
            else if (DAY[da][wo] == 10 && last != 0)
                // If there is more than one senior who is not searched, return 0
                return 0;
        }
    }
    return last;
}

long long WORKER_LAST(int da)
/****************************
 * If the number of remaining unscheduled employees (greater than 0)
 * plus the number of employees on duty is exactly equal to least_ worker
 * return the number of employee number combinations of these employees,
 * otherwise return 0
 * ********************************************************************************/
{
    int work_num = 0, last_num = 0, work[MAX_WORKERS], last[MAX_WORKERS];
    for (int wo = 1; wo <= num_workers; wo++)
    {
        if (DAY[da][wo] == 1) // If an employee works today, record it
        {
            work_num++;
            work[work_num] = wo;
        }
        if (DAY[da][wo] == 10) // If an employee is unsearched today, record it
        {
            last_num++;
            last[last_num] = wo;
        }
    }
    if (last_num > 0 && work_num + last_num == least_worker)
    {
        long long sum = 0;
        while (last_num != 0)
        {
            sum *= MAX_WORKERS;
            sum += last[last_num];
            last_num--;
        }
        return sum;
    }
    return 0;
}

int WORK_DAY(int wo)
// Returns the number of days employee wo works this week
{
    int sum = 0;
    for (int da = 1; da <= 7; da++)
        if (DAY[da][wo] == 1)
            sum++;
    return sum;
}

void OutPut()
{
    for (int da = 1; da <= 7; da++)
    {
        for (int wo = 1; wo <= num_workers; wo++)
        {
            if (DAY[da][wo] == 1)
                printf("%4d", wo);
#if DEBUG
            else if (DAY[da][wo] == 0)
                printf("   0");
            else
                printf("None");
#endif
        }
        printf("\n");
    }
#if DOMAIN_TEST
    for (int da = 1; da <= 7; da++)
    {
        for (int wo = 1; wo <= num_workers; wo++)
        {
            printf("%d%d ", domain[da][wo][0], domain[da][wo][1]);
        }
        printf("\n");
    }
#endif
}
