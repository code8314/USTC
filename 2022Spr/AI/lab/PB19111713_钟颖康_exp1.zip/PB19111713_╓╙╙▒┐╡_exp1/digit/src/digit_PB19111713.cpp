/********************************************************************************
 * Description  :
 * Version      : 1.0
 * Author       : YingKang Zhong
 * Date         : 2022-04-30 10:54:31
 * LastEditors  : YingKang Zhong
 * LastEditTime : 2022-05-02 15:11:06
 * FilePath     : \\PB19111713_钟颖康_exp1\\digit\\src\\digit_PB19111713.cpp
 * Copyright (C) 2022 YingKang Zhong. All rights reserved.
 ********************************************************************************/
#pragma warning(disable : 4996)
#include <stdio.h>
#include <time.h>
#include <malloc.h>
#include <string>
#include <queue>
#include <cstring>
#include <math.h>
#include <time.h>

#define UP 0
#define DOWN 1
#define LEFT 2
#define RIGHT 3

#define TIME_OUTPUT 0
#define PorF_OUTPUT 0
#define DEBUG 0

#include <vector>
using namespace std;
void A_h1(const vector<vector<int>> &start, const vector<vector<int>> &target);
void A_h2(const vector<vector<int>> &start, const vector<vector<int>> &target);
void IDA_h1(const vector<vector<int>> &start, const vector<vector<int>> &target);
void IDA_h2(const vector<vector<int>> &start, const vector<vector<int>> &target);

int START[25];  // INPUT
int TARGET[25]; // TARGET
int SOLUTION[500];
int H_TYPE = 1;

typedef struct Tree
{
    int a[25]; // planet status
    int i;     // spaceship location
    int dir;   // direction of spaceship latest movement
    int g_val;
    int h1_val;
    int h2_val;
    struct Tree *father;
    struct Tree *up;
    struct Tree *down;
    struct Tree *left;
    struct Tree *right;
};

struct cmp_h
{
    bool operator()(const Tree &g1, const Tree &g2)
    {
        if (H_TYPE == 1)
            return g1.g_val + g1.h1_val > g2.g_val + g2.h1_val;
        else if (H_TYPE == 2)
            return g1.g_val + g1.h2_val > g2.g_val + g2.h2_val;
    }
};

Tree *Tree_create();
Tree *Tree_create_node();
int h1_value(int a[], int b[]);
int h2_value(int a[], int b[]);
int move(Tree *t, int direction);
void A_STAR();
void IDA_STAR(int DEPTH);

int DISTANCE(int a, int b);
int MIN(int a, int b);
int MAX(int a, int b);

int main(int argc, char **argv)
{
    int i, j;
    int tmp;
    /* init start */
    string Fi = "data/";
    Fi += argv[2];
    freopen(Fi.c_str(), "r", stdin);
    vector<vector<int>> start, target;
    for (i = 0; i <= 4; i++)
    {
        vector<int> TMP;
        start.push_back(TMP);
        for (j = 0; j <= 4; j++)
        {
            scanf("%d", &tmp);
            start[i].push_back(tmp);
        }
    }
    fclose(stdin);

    /* init target */
    Fi = "data/";
    Fi += argv[3];
    freopen(Fi.c_str(), "r", stdin);
    for (i = 0; i <= 4; i++)
    {
        vector<int> TMP;
        target.push_back(TMP);
        for (j = 0; j <= 4; j++)
        {
            scanf("%d", &tmp);
            target[i].push_back(tmp);
        }
    }
    fclose(stdin);

    /* solution */
    freopen("output.txt", "w", stdout);

    if (strcmp("A_h1", argv[1]) == 0)
        A_h1(start, target);
    if (strcmp("A_h2", argv[1]) == 0)
        A_h2(start, target);
    if (strcmp("IDA_h1", argv[1]) == 0)
        IDA_h1(start, target);
    if (strcmp("IDA_h2", argv[1]) == 0)
        IDA_h2(start, target);

    fclose(stdout);

    return 0;
}

void A_h1(const vector<vector<int>> &start, const vector<vector<int>> &target)
{
    for (int i = 0; i < 5; i++)
        for (int j = 0; j < 5; j++)
        {
            START[i * 5 + j] = start[i][j];
            TARGET[i * 5 + j] = target[i][j];
        }
    H_TYPE = 1; /* use h1() */
#if TIME_OUTPUT
    clock_t begin = clock();
#endif
    A_STAR();
#if TIME_OUTPUT
    printf("\n%ld millisecond\n", clock() - begin);
#endif
}

void A_h2(const vector<vector<int>> &start, const vector<vector<int>> &target)
{
    for (int i = 0; i < 5; i++)
        for (int j = 0; j < 5; j++)
        {
            START[i * 5 + j] = start[i][j];
            TARGET[i * 5 + j] = target[i][j];
        }
    H_TYPE = 2; /* use h2() */
#if TIME_OUTPUT
    clock_t begin = clock();
#endif
    A_STAR();
#if TIME_OUTPUT
    printf("\n%ld millisecond\n", clock() - begin);
#endif
}

void IDA_h1(const vector<vector<int>> &start, const vector<vector<int>> &target)
{
    for (int i = 0; i < 5; i++)
        for (int j = 0; j < 5; j++)
        {
            START[i * 5 + j] = start[i][j];
            TARGET[i * 5 + j] = target[i][j];
        }
    H_TYPE = 1; /* use h1() */
#if TIME_OUTPUT
    clock_t begin = clock();
#endif
    IDA_STAR(1);
#if TIME_OUTPUT
    printf("\n%ld millisecond\n", clock() - begin);
#endif
}

void IDA_h2(const vector<vector<int>> &start, const vector<vector<int>> &target)
{
    for (int i = 0; i < 5; i++)
        for (int j = 0; j < 5; j++)
        {
            START[i * 5 + j] = start[i][j];
            TARGET[i * 5 + j] = target[i][j];
        }
    H_TYPE = 2; /* use h2() */
#if TIME_OUTPUT
    clock_t begin = clock();
#endif
    IDA_STAR(1);
#if TIME_OUTPUT
    printf("\n%ld millisecond\n", clock() - begin);
#endif
}

void A_STAR()
{
    int flag = 0; // flag == 1 means search succeeded, exit the loop
    int step = 0;
    int state = 0; // total number of states during search
    int i = 0;

    Tree *AS_Tree = Tree_create();
    priority_queue<Tree, vector<Tree>, cmp_h> searchList; /* cmp_h varies with global variable H_TYPE */
    searchList.push(*AS_Tree);

    Tree now = searchList.top();
    Tree *father_in_tree = Tree_create_node();

    while (!searchList.empty())
    {
        searchList.pop();
        for (int direction = 0; direction < 4; direction++)
        {
            if (move(&now, direction) && direction + now.dir != 1 && direction + now.dir != 5)
            /****************************************************************************************
             *   If it can be moved in a certain direction and is not opposite to the previous step,
             *   the direction status will be put into the priority queue
             ****************************************************************************************/
            {
                /* Find the position of the pop-up element of the priority queue in the orginal search tree */
                if (now.father == NULL)
                    father_in_tree = AS_Tree;
                else
                {
                    switch (now.dir)
                    {
                    case UP:
                        father_in_tree = now.father->up;
                        break;
                    case DOWN:
                        father_in_tree = now.father->down;
                        break;
                    case LEFT:
                        father_in_tree = now.father->left;
                        break;
                    case RIGHT:
                        father_in_tree = now.father->right;
                        break;
                    default:
                        break;
                    }
                }
                /* complete the element of child */
                Tree *child = Tree_create_node();
                child->father = father_in_tree;
                for (i = 0; i < 25; i++)
                    child->a[i] = now.a[i];
                switch (direction)
                {
                case UP:
                    child->dir = UP;
                    father_in_tree->up = child;
                    if (now.i == 2)
                    /*********************************************************
                     * There is a channel above the spaceship,
                     * and the other side of the channel is not a black hole
                     *********************************************************/
                    {
                        child->a[2] = child->a[22];
                        child->a[22] = 0;
                        child->i = 22;
                    }
                    else
                    {
                        child->a[now.i] = child->a[now.i - 5];
                        child->a[now.i - 5] = 0;
                        child->i = now.i - 5;
                    }
                    child->g_val = now.g_val + 1;
                    child->h1_val = h1_value(child->a, TARGET);
                    child->h2_val = h2_value(child->a, TARGET);
                    break;
                case DOWN:
                    child->dir = DOWN;
                    father_in_tree->down = child;
                    if (now.i == 22)
                    /*********************************************************
                     * There is a channel below the spaceship,
                     * and the other side of the channel is not a black hole
                     *********************************************************/
                    {
                        child->a[22] = child->a[2];
                        child->a[2] = 0;
                        child->i = 2;
                    }
                    else
                    {
                        child->a[now.i] = child->a[now.i + 5];
                        child->a[now.i + 5] = 0;
                        child->i = now.i + 5;
                    }
                    child->g_val = now.g_val + 1;
                    child->h1_val = h1_value(child->a, TARGET);
                    child->h2_val = h2_value(child->a, TARGET);
                    break;
                case LEFT:
                    child->dir = LEFT;
                    father_in_tree->left = child;
                    if (now.i == 10)
                    /*******************************************************
                     * The left side of the spacecraft is a channel,
                     *and the other side of the channel is not a black hole
                     *******************************************************/
                    {
                        child->a[10] = child->a[14];
                        child->a[14] = 0;
                        child->i = 14;
                    }
                    else
                    {
                        child->a[now.i] = child->a[now.i - 1];
                        child->a[now.i - 1] = 0;
                        child->i = now.i - 1;
                    }
                    child->g_val = now.g_val + 1;
                    child->h1_val = h1_value(child->a, TARGET);
                    child->h2_val = h2_value(child->a, TARGET);
                    break;
                case RIGHT:
                    child->dir = RIGHT;
                    father_in_tree->right = child;
                    if (now.i == 14)
                    /*******************************************************
                     * The right side of the spacecraft is a channel,
                     *and the other side of the channel is not a black hole
                     *******************************************************/
                    {
                        child->a[14] = child->a[10];
                        child->a[10] = 0;
                        child->i = 10;
                    }
                    else
                    {
                        child->a[now.i] = child->a[now.i + 1];
                        child->a[now.i + 1] = 0;
                        child->i = now.i + 1;
                    }
                    child->g_val = now.g_val + 1;
                    child->h1_val = h1_value(child->a, TARGET);
                    child->h2_val = h2_value(child->a, TARGET);
                    break;
                default:
                    break;
                }
                searchList.push(*child);
                state++;
#if DEBUG
                printf("%d\n", state);
                for (int poi = 0; poi <= 24; poi++)
                    printf(((poi % 5 == 4) ? ("%d\n") : ("%d ")), child->a[poi]);
                printf("%d %d", child->g_val, child->h1_val);
                puts("");
                char ch = getchar();
#endif
                if (child->h1_val == 0)
                /**********************************************************
                 * If each planet reaches the target position,
                 * the search is successful and start to find the solution
                 **********************************************************/
                {
                    flag = 1;
                    for (step = 0; child->father != NULL; step++)
                    {
                        SOLUTION[step] = child->dir;
                        child = child->father;
                    }
                }
            }
        }
        if (flag) /* already got the solution */
            break;
        now = searchList.top();
    }
    if (flag == 0)
    {
#if PorF_OUTPUT
        printf("\nsearch failed\n");
#endif
        return;
    }
    else
    {
        for (step--; step >= 0; step--)
        {
            switch (SOLUTION[step])
            {
            case UP:
                printf("U");
                break;
            case DOWN:
                printf("D");
                break;
            case LEFT:
                printf("L");
                break;
            case RIGHT:
                printf("R");
                break;
            default:
                break;
            }
        }
#if PorF_OUTPUT
        printf("\nsearch succeed\n");
#endif
    }
}

void IDA_STAR(int DEPTH)
/* Largely copied from A_STAR() */
{
    int flag = 0; // flag == 1 means search succeeded, exit the loop
    int step = 0;
    int state = 0; // total number of states during search
    int i = 0;
    int tmp_DEPTH = 0;

    Tree *AS_Tree = Tree_create();
    priority_queue<Tree, vector<Tree>, cmp_h> searchList; /* cmp_h varies with global variable H_TYPE */
    searchList.push(*AS_Tree);

    Tree now = searchList.top();
    Tree *father_in_tree = Tree_create_node();

    clock_t begin = clock();

    while (!searchList.empty())
    {
        searchList.pop();
        if (now.g_val + now.h1_val <= DEPTH && H_TYPE == 1 || now.g_val + now.h2_val <= DEPTH && H_TYPE == 2)
        /***************************************************
         * If the evaluation is not greater than DEPTH,
         * it will be executed normally
         ***************************************************/
        {
            for (int direction = 0; direction < 4; direction++)
            {
                if (move(&now, direction) && direction + now.dir != 1 && direction + now.dir != 5)
                /****************************************************************************************
                 *   If it can be moved in a certain direction and is not opposite to the previous step,
                 *   the direction status will be put into the priority queue
                 ****************************************************************************************/
                {
                    /* Find the position of the pop-up element of the priority queue in the orginal search tree */
                    if (now.father == NULL)
                        father_in_tree = AS_Tree;
                    else
                    {
                        switch (now.dir)
                        {
                        case UP:
                            father_in_tree = now.father->up;
                            break;
                        case DOWN:
                            father_in_tree = now.father->down;
                            break;
                        case LEFT:
                            father_in_tree = now.father->left;
                            break;
                        case RIGHT:
                            father_in_tree = now.father->right;
                            break;
                        default:
                            break;
                        }
                    }
                    /* complete the element of child */
                    Tree *child = Tree_create_node();
                    child->father = father_in_tree;
                    for (i = 0; i < 25; i++)
                        child->a[i] = now.a[i];
                    switch (direction)
                    {
                    case UP:
                        child->dir = UP;
                        father_in_tree->up = child;
                        if (now.i == 2)
                        /*********************************************************
                         * There is a channel above the spaceship,
                         * and the other side of the channel is not a black hole
                         *********************************************************/
                        {
                            child->a[2] = child->a[22];
                            child->a[22] = 0;
                            child->i = 22;
                        }
                        else
                        {
                            child->a[now.i] = child->a[now.i - 5];
                            child->a[now.i - 5] = 0;
                            child->i = now.i - 5;
                        }
                        child->g_val = now.g_val + 1;
                        child->h1_val = h1_value(child->a, TARGET);
                        child->h2_val = h2_value(child->a, TARGET);
                        break;
                    case DOWN:
                        child->dir = DOWN;
                        father_in_tree->down = child;
                        if (now.i == 22)
                        /*********************************************************
                         * There is a channel below the spaceship,
                         * and the other side of the channel is not a black hole
                         *********************************************************/
                        {
                            child->a[22] = child->a[2];
                            child->a[2] = 0;
                            child->i = 2;
                        }
                        else
                        {
                            child->a[now.i] = child->a[now.i + 5];
                            child->a[now.i + 5] = 0;
                            child->i = now.i + 5;
                        }
                        child->g_val = now.g_val + 1;
                        child->h1_val = h1_value(child->a, TARGET);
                        child->h2_val = h2_value(child->a, TARGET);
                        break;
                    case LEFT:
                        child->dir = LEFT;
                        father_in_tree->left = child;
                        if (now.i == 10)
                        /*******************************************************
                         * The left side of the spacecraft is a channel,
                         *and the other side of the channel is not a black hole
                         *******************************************************/
                        {
                            child->a[10] = child->a[14];
                            child->a[14] = 0;
                            child->i = 14;
                        }
                        else
                        {
                            child->a[now.i] = child->a[now.i - 1];
                            child->a[now.i - 1] = 0;
                            child->i = now.i - 1;
                        }
                        child->g_val = now.g_val + 1;
                        child->h1_val = h1_value(child->a, TARGET);
                        child->h2_val = h2_value(child->a, TARGET);
                        break;
                    case RIGHT:
                        child->dir = RIGHT;
                        father_in_tree->right = child;
                        if (now.i == 14)
                        /*******************************************************
                         * The right side of the spacecraft is a channel,
                         *and the other side of the channel is not a black hole
                         *******************************************************/
                        {
                            child->a[14] = child->a[10];
                            child->a[10] = 0;
                            child->i = 10;
                        }
                        else
                        {
                            child->a[now.i] = child->a[now.i + 1];
                            child->a[now.i + 1] = 0;
                            child->i = now.i + 1;
                        }
                        child->g_val = now.g_val + 1;
                        child->h1_val = h1_value(child->a, TARGET);
                        child->h2_val = h2_value(child->a, TARGET);
                        break;
                    default:
                        break;
                    }
                    searchList.push(*child);
                    state++;
#if DEBUG
                    printf("%d\n", state);
                    for (int poi = 0; poi <= 24; poi++)
                        printf(((poi % 5 == 4) ? ("%d\n") : ("%d ")), child->a[poi]);
                    printf("%d %d", child->g_val, child->h1_val);
                    puts("");
                    char ch = getchar();
#endif
                    if (child->h1_val == 0)
                    /**********************************************************
                     * If each planet reaches the target position,
                     * the search is successful and start to find the solution
                     **********************************************************/
                    {
                        flag = 1;
                        for (step = 0; child->father != NULL; step++)
                        {
                            SOLUTION[step] = child->dir;
                            child = child->father;
                        }
                    }
                }
            }
        }
        tmp_DEPTH = MAX(tmp_DEPTH, (H_TYPE == 1) ? (now.g_val + now.h1_val) : (now.g_val + now.h2_val));
        if (flag) /* already got the solution */
            break;
        now = searchList.top();
    }

    if (flag == 0 && DEPTH >= tmp_DEPTH)
    {
#if PorF_OUTPUT
        printf("\nsearch failed\n");
#endif
        return;
    }
    else if (flag == 0)
        IDA_STAR(tmp_DEPTH);
    else
    {
        for (step--; step >= 0; step--)
        {
            switch (SOLUTION[step])
            {
            case UP:
                printf("U");
                break;
            case DOWN:
                printf("D");
                break;
            case LEFT:
                printf("L");
                break;
            case RIGHT:
                printf("R");
                break;
            default:
                break;
            }
        }
#if PorF_OUTPUT
        printf("\nsearch succeed\n");
#endif
    }
    return;
}

Tree *Tree_create()
/**************************************
 * Create root node of search tree
 **************************************/
{
    Tree *Tree = (struct Tree *)malloc(sizeof(struct Tree));
    if (Tree == NULL)
        return NULL;

    Tree->father = NULL;
    Tree->up = NULL;
    Tree->down = NULL;
    Tree->left = NULL;
    Tree->right = NULL;
    Tree->dir = -100;
    int tmp = 0;
    for (int i = 0; i < 25; i++)
    {
        Tree->a[i] = START[i];
        if (START[i] == 0)
            tmp = i;
    }
    Tree->i = tmp;
    Tree->g_val = 0;
    Tree->h1_val = h1_value(Tree->a, TARGET);
    Tree->h2_val = h2_value(Tree->a, TARGET);

    return Tree;
}

Tree *Tree_create_node()
/******************************
 * Create node of search tree
 ******************************/
{
    Tree *Tree = (struct Tree *)malloc(sizeof(struct Tree));
    if (Tree == NULL)
        return NULL;

    Tree->father = NULL;
    Tree->up = NULL;
    Tree->down = NULL;
    Tree->left = NULL;
    Tree->right = NULL;

    return Tree;
}

int DISTANCE(int a, int b)
{
    int x, y;
    x = abs(a - b) / 5;
    y = abs(a - b) - 5 * x;
    return x + y;
}

int MIN(int a, int b)
{
    return (a < b) ? a : b;
}

int MAX(int a, int b)
{
    return (a > b) ? a : b;
}

int h1_value(int a[], int b[])
/*********************************************************************************
 * Spaceship misplacement is not included in the number of misplaced planets
 *********************************************************************************/
{
    int i, sum = 0;
    for (i = 0; i < 25; i++)
    {
        if (a[i] == 0 && b[i] == 0)
            sum++;
        else if (a[i] == b[i])
            continue;
        else
            sum++;
    }
    return sum - 1;
}

int h2_value(int a[], int b[])
/************************************************
 * the distance of spaceship is not included
 ************************************************/
{
    int sum = 0, min = 0;
    int dist, dist_UP, dist_DOWN, dist_LEFT, dist_RIGHT;
    int position;
    for (int i = 0; i < 25; i++)
    {
        if (a[i] == 0)
            continue;
        for (position = 0; position < 25; position++)
        /* find the target place of planet i */
        {
            if (a[i] != b[position])
                continue;
            else
                break;
        }
        dist = DISTANCE(i, position);
        dist_UP = DISTANCE(i, 2) + DISTANCE(22, position) + 1;
        dist_DOWN = DISTANCE(i, 22) + DISTANCE(2, position) + 1;
        dist_LEFT = DISTANCE(i, 10) + DISTANCE(14, position) + 1;
        dist_RIGHT = DISTANCE(i, 14) + DISTANCE(10, position) + 1;
        min = MIN(dist, dist_UP);
        min = MIN(min, dist_DOWN);
        min = MIN(min, dist_LEFT);
        min = MIN(min, dist_RIGHT);
        sum = sum + min;
    }
    return sum;
}

int move(Tree *t, int direction)
{
    switch (direction)
    {
    case UP:
        if (t->i > 4 && t->a[t->i - 5] >= 0)
            /***************************************************************
             * The grid above the spaceship is not a wall or black hole
             ***************************************************************/
            return 1;
        else if (t->i == 2 && t->a[22] >= 0)
            /***************************************************************
             * There is a channel above the spaceship,
             * and the other side of the channel is not a black hole
             ***************************************************************/
            return 1;
        break;
    case DOWN:
        if (t->i < 20 && t->a[t->i + 5] >= 0)
            /***************************************************************
             * The grid below the spaceship is not a wall or black hole
             ***************************************************************/
            return 1;
        else if (t->i == 22 && t->a[2] >= 0)
            /***************************************************************
             * There is a channel below the spaceship,
             * and the other side of the channel is not a black hole
             ***************************************************************/
            return 1;
        break;
    case LEFT:
        if (t->i % 5 != 0 && t->a[t->i - 1] >= 0)
            /***************************************************************
             * The grid left to the spaceship is not a wall or black hole
             ***************************************************************/
            return 1;
        else if (t->i == 10 && t->a[14] >= 0)
            /***************************************************************
             * There is a channel left to the spaceship,
             * and the other side of the channel is not a black hole
             ***************************************************************/
            return 1;
        break;
    case RIGHT:
        if (t->i % 5 != 4 && t->a[t->i + 1] >= 0)
            /***************************************************************
             * The grid right to the spaceship is not a wall or black hole
             ***************************************************************/
            return 1;
        else if (t->i == 14 && t->a[10] >= 0)
            /***************************************************************
             * There is a channel right to the spaceship,
             * and the other side of the channel is not a black hole
             ***************************************************************/
            return 1;
        break;
    default:
        return 0;
    }
    return 0;
}
