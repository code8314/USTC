import socket
import threading
from time import time

class DNS_Relay_Server:  # 一个relay server实例，通过缓存文件和外部地址来初始化
    def __init__(self, cache_file, name_server):
        # url_IP字典:通过域名查询ID
        self.url_ip = {}
        self.cache_file = cache_file
        self.load_file()
        self.name_server = name_server
        # trans字典：通过DNS响应的ID来获得原始的DNS数据包发送方
        self.trans = {}

    def load_file(self, ):
        f = open(self.cache_file, 'r', encoding='utf-8')
        for line in f:
            ip, name = line.split(' ')
            self.url_ip[name.strip('\n')] = ip
        f.close()

    def run(self):
        buffer_size = 512
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        server_socket.bind(('', 53))
        server_socket.setblocking(False)
        while True:
            try:
                data, addr = server_socket.recvfrom(buffer_size)
                threading.Thread(target=self.handle, args=(server_socket, data, addr)).start()
            except:
                continue

    def handle(self, server_socket, data, addr):
        start = time()
        #print(start)
        RecvDp = DNS_Packege(data)
        #query
        if RecvDp.QR == 0:
            print(RecvDp.name)
            if RecvDp.name in self.url_ip and RecvDp.QType == 1:
                if (self.url_ip[RecvDp.name] == '0.0.0.0'):
                    responce = RecvDp.generate_response(self.url_ip[RecvDp.name], True)
                    print('----------INTERCEPT----------', sep='\t')
                else:
                    responce = RecvDp.generate_response(self.url_ip[RecvDp.name], False)
                    print('----------RESOLVED----------', sep='\t')
                server_socket.sendto(responce, addr)

            else:
                #print('test1')
                server_socket.sendto(data, self.name_server)
                #print('test2')
                self.trans[RecvDp.ID] = (addr, self.name_server, start)
                #print('test3')
            # statement
        #responce
        if RecvDp.QR == 1:
            print(RecvDp.name)
            if RecvDp.ID in self.trans:
                client_addr, client_name, client_start = self.trans[RecvDp.ID]
                server_socket.sendto(data, client_addr)
                print('----------RELAY----------', sep='\t')
                del self.trans[RecvDp.ID]
            # statement


class DNS_Packege:  # 一个DNS Frame实例，用于解析和生成DNS帧
    def __init__(self, data):
        self.data = data
        Msg_arr = bytearray(data)
        # ID
        self.ID = (Msg_arr[0] << 8) + Msg_arr[1]
        # FLAGS
        self.QR = Msg_arr[2] >> 7
        # 资源记录数量
        self.QDCOUNT = (Msg_arr[4] << 8) + Msg_arr[5]
        # query内容解析
        self.name = ""
        self.name_length = 0
        start = 12
        for i in range(self.QDCOUNT):
            mark = False
            while True:
                if Msg_arr[start] != 0:
                    if mark:
                        self.name += '.'

                    num = Msg_arr[start]

                    start += 1
                    for j in range(num):
                        self.name += chr(Msg_arr[start])
                        start += 1
                        mark=True
                else:
                    break
        start += 1
        self.QType = (Msg_arr[start] << 8) + Msg_arr[start + 1]
        start += 2
        self.Clas = (Msg_arr[start] << 8) + Msg_arr[start + 1]
        start += 2
        self.name_length = start - 12

    def generate_response(self, ip, Intercepted):
        res = bytearray(32 + self.name_length)
        res[0] = self.ID >> 8
        res[1] = self.ID % 256
        if Intercepted:
            res[2] = 0x85
            res[3] = 0x83
        else:
            res[2] = 0x81
            res[3] = 0x80
        res[4] = self.QDCOUNT >> 8
        res[5] = self.QDCOUNT % 256
        res[6] = 0x00
        res[7] = 0x01
        res[8] = 0x00
        res[9] = 0x00
        res[10] = 0x00
        res[11] = 0x00
        for i in range(12, self.name_length+12):
            res[i] = self.data[i]
        ans = self.name_length+12
        res[ans] = 0xC0
        ans += 1
        res[ans] = 0x0C
        ans += 1
        res[ans] = 0x00
        ans += 1
        res[ans] = 0x01
        ans += 1
        res[ans] = 0x00
        ans += 1
        res[ans] = 0x01
        ans += 1
        res[ans] = 0x00
        ans += 1
        res[ans] = 0x00
        ans += 1
        res[ans] = 0x00
        ans += 1
        res[ans] = 200
        ans += 1
        res[ans] = 0x00
        ans += 1
        res[ans] = 0x04
        ans += 1
        if Intercepted:
            res[ans] = 0x00
            ans += 1
            res[ans] = 0x00
            ans += 1
            res[ans] = 0x00
            ans += 1
            res[ans] = 0x00
        else:
            sp = ip.split('.')
            res[ans] = int(sp[0])
            ans += 1
            res[ans] = int(sp[1])
            ans += 1
            res[ans] = int(sp[2])
            ans += 1
            res[ans] = int(sp[3])
        return bytes(res)


if __name__ == '__main__':
    cache_file = 'example.txt'
    name_server = ('223.5.5.5', 53)
    relay_server = DNS_Relay_Server(cache_file, name_server)  # 构造一个DNS_Relay_Server实例
    relay_server.run()
